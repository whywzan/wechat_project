from django.http import HttpResponse
from django.shortcuts import render



def test_token(request):
    if request.method == 'GET':
        signature = request.GET["signature"]
        print(signature)
    return HttpResponse("6666")